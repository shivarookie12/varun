const mongoose = require('mongoose');

const returnSchema = mongoose.Schema({
    invoiceNo     :   String,
    returnType   :   String,
    reasonType    :   String,
    returnReason :   String
});

module.exports = mongoose.model("Returns",returnSchema);