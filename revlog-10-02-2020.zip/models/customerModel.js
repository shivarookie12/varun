const mongoose = require('mongoose');

const customerSchema = mongoose.Schema({
    customercode :{
        type: String,
        unique : true,
        required : true
        
    },
    employeename	: {
        type: String,
        required : true
    },
    function : {
        type: String,
        required : true
    },
    region : {
        type: String,
        required : true
    },
    customertype : {
        type: String,
        required : true
    },
    mobilenumber : {
        type: String,
        required : true
    },	
    email : {
        type: String,
        required : true
    },
    address1 : {
        type: String,
        required : true
    },
    address2 : {
        type: String,
    
    },	
    pincode : {
        type: Number
    },
    state : {
        type: String,
        required : true
    },
    country : {
        type: String,
        required : true
    },	
    assignedto : {
        type: String,
        required : true
    },
    status : {
        type: Boolean
    },
    createddate : {
        type: Date
     
    },
    modifieddate : {
        type: Date
     
    }
});

module.exports = mongoose.model("customer",customerSchema);