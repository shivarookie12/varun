const mongoose = require('mongoose');

const returnListSchema = mongoose.Schema({
    id     :   String,
    value   :   String,
    dealer    :   String,
    dcode :   String,
    reporter : String,
    assignee : String
});

module.exports = mongoose.model("ReturnList",returnListSchema);