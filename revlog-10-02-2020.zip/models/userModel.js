const mongoose = require('mongoose');

const userSchema = mongoose.Schema({
    employeecode :{
        type: String,
        unique : true,
        required: true
    },
    employeename	: {
        type: String,
        required: true
    },
    designation : {
        type: String,
        required: true
    },
    function : {
        type: String,
        required: true
    },
    region : {
        type: String,
        required: true
    },
    usertype : {
        type: String,
        required: true
    },	
    mobilenumber : {
        type: Number,
        required: true
    },
    email : {
        type: String,
        required: true
    },
    managercode : {
        type: String,
        required: true
    },	
    managername : {
        type: String
    },
    status : {
        type: Boolean
    },
    createddate : {
        type: Date
     
    },
    modifieddate : {
        type: Date
     
    }
});

module.exports = mongoose.model("Users",userSchema);