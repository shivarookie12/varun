const mongoose = require('mongoose');

const productSchema =  mongoose.Schema({
    productcode :{
        type: String,
        unique : true,
        required: true
    },
    description	: {
        type: String,
        required: true
    },
    mfgortraded : {
        type: String,
        required: true
    },
    productgroup : {
        type: String,
        required: true
    },
    producttype : {
        type: String
    },
    productstatus : {
        type: String
    },	
    productprice : {
        type: Number
    },
    productmodel : {
        type: String,
        required: true
    },
    status : {
        type: Boolean
    },	
    createddate : {
        type: Date
    },
    modifieddate : {
        type: Date
     
    }
});

module.exports = mongoose.model("product",productSchema);


