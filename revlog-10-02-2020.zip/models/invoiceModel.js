const mongoose = require('mongoose');

const invoiceSchema = mongoose.Schema({
    invoiceNo     :   String,
    date   :   String,
    SBU    :   String,
    customerCode :   String,
    purchased        :   String,
    value        :   String
});

module.exports = mongoose.model("Invoice",invoiceSchema);