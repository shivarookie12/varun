const mongoose = require('mongoose');
const validator = require('validator');

const userLoginSchema = mongoose.Schema({
    email: {
        type: String,
        lowercase: true,
        unique: true,
        required: 'Email address is required',
        validate: { validator: validator.isEmail , message: 'Invalid email.' }
    },
    password:{
        type: String,
        required : true
    }
});

module.exports = mongoose.model("uLogin",userLoginSchema);