var path = require('path');
const router = require('express').Router()
const token = require('../token/token.js');
const auth = require('../controller/authVerifier.js')
const loginController = require('../controller/loginController.js');
const userController = require('../controller/userController.js');
const importController = require('../controller/importController.js');
const pageController = require('../controller/paginationController.js');
const searchController = require('../controller/searchController.js');
const returnController = require('../controller/returnController.js');
const findController = require('../controller/findController.js');
const mail = require('../controller/mail.js');

router.post('/register',loginController.register)
router.post('/login',loginController.login)
router.post('/refreshtoken',loginController.refreshToken)


router.post('/api/v1/upload',auth.authVerification,importController.uploadFile)




router.post('/api/v1/getCustomerCount',auth.authVerification,findController.getCustomerCount)
router.post('/api/v1/getProductCount',auth.authVerification,findController.getProductCount)
router.post('/api/v1/getBusinessUserCount',auth.authVerification,findController.getBusinessUserCount)

router.post('/api/v1/getCustomerList',auth.authVerification,pageController.customerPaginate)
router.post('/api/v1/getProductList',auth.authVerification,pageController.productPaginate)
router.post('/api/v1/getBsusersList',auth.authVerification,pageController.bsUserPaginate)


router.post('/api/v1/getByIdOrPhone',auth.authVerification,searchController.getByIdOrPhone)
router.post('/api/v1/sendmail',auth.authVerification,mail.sendMail)
router.post('/api/v1/addInvoice',auth.authVerification,returnController.addInvoice)
router.post('/api/v1/addReturn',auth.authVerification,returnController.addReturn)
router.get('/api/v1/getUserDetails/:id',auth.authVerification,userController.getUser)
router.get('/api/v1/getInvoice/:invoiceNo',auth.authVerification,returnController.getInvoice)
router.get('/api/v1/getReturn/:invoiceNo',auth.authVerification,returnController.getReturnById)


module.exports = router

