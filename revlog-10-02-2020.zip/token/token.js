const jwt = require('jsonwebtoken');
const config = require('../config/config.js');

module.exports.tokenGenerate = function(user){
    const token = jwt.sign(user, config.tokenConfig.secret, { expiresIn: config.tokenConfig.tokenLife})
    return token;
}
module.exports.refreshToken = function(user){
    const refreshToken = jwt.sign(user,config.tokenConfig.refreshTokenSecret, { expiresIn: config.tokenConfig.refreshTokenLife})
    return refreshToken;
}
