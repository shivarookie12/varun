const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const helmet = require('helmet')
const path = require('path');
const cors = require('cors')
const dbConfig = require('./config/config.js');

const mongoose = require('mongoose');
const router = require('./router');
//var redisConnect = require('./config/redisServer');
const port = process.env.port || 5000;
app.use(helmet());
app.use(bodyParser.json());
app.use(cors());
app.use(bodyParser.urlencoded({
    extended:true
}))
app.use(function (req, res,next) {
    res.header('Access-Control-Allow-Origin', '*')
    res.header('Access-Control-Allow-Headers', 'x-access-token,Content-Type')
    res.header('Access-Control-Expose-Headers', 'x-access-token,Content-Type')
    res.header('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS')
    res.header('Content-Type', 'application/json')
    next();
  })
/*app.use(redisConnect,function(req,res,next){
    next();
})*/

global.rootPath = path.dirname(require.main.filename || process.mainModule.filename)
mongoose.Promise = global.Promise;

// Connecting to the database
mongoose.connect(dbConfig.mongoConfig.url, {
    useNewUrlParser: true
}).then(() => {
    console.log("Successfully connected to the database");    
}).catch(err => {
    console.log('Could not connect to the database. Exiting now...', err);
    process.exit();
});
app.use('/',router)
app.listen(port, function(){
    console.log("app running in port : "+port);
})