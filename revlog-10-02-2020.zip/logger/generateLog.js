var logger = exports;
var fs = require('fs');
logger.debugLevel = 'warn';
logger.log = function(level, message) {
  var levels = ['info', 'warn', 'error'];
    if (typeof message !== 'string') {
      message = JSON.stringify(message);

    };
    console.log(level+': '+message);
fs.appendFile('./log.txt', message+"\n", function (err) { 
                        if (err)
        console.log(err);
                        else
        console.log('Write operation complete.');
});
}
