const winston = require('winston');
const { combine, timestamp, prettyPrint } = winston.format;
const logger = winston.createLogger({
    level: 'info',
    format: combine(
      timestamp(),
      prettyPrint()
    ),
    transports: [
        new winston.transports.File({ filename: './logger/error.log', level: 'error' }),
        new winston.transports.File({ filename: './logger/combined.log' })
    ]
});
//logger.log=logger.info;

module.exports = logger;