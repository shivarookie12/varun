var redis = require('redis');
var redisConfig = require('./config.js')
var client = redis.createClient(redisConfig.redisPort,redisConfig.redisHost);
client.on('connect',function(){
console.log("redis connected");
});
exports.setFunction = () =>{
client.set('age','22',function(err,reply){
    console.log(reply);
});
client.get('age',function(err,reply){
    console.log(reply);
});

//console.log("hello");
}

