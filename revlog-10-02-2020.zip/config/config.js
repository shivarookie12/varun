module.exports.tokenConfig={
    "secret": "neuui",
    "refreshTokenSecret": "neuui",
    "port": 5000,
    "tokenLife": 9000,
    "refreshTokenLife": 9000
}
module.exports.redisConfig={
    redisHost : "127.0.0.1",
    redisPort : "6379"
}
module.exports.mongoConfig = {
    url : 'mongodb://localhost:27017/revlog'
}
