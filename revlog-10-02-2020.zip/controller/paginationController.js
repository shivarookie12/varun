var customerPagination = require('../models/customerModel.js');
var productPagination = require('../models/productModel.js');
var bsUserPagination = require('../models/userModel.js');
module.exports.customerPaginate = function(req,res){
    var responses = {};
  var reqFilter = req.body.filter;
 // console.log(reqFilter)
    if(req.body.pageNo && req.body.size){
        var pageNo = parseInt(req.body.pageNo)
        var size = parseInt(req.body.size)
        if(pageNo < 0 || pageNo === 0) {
            responses = {code : "400",message : "page number greater than 0"}; 
           return  res.send(responses);
            
        }
        commonPaginate(customerPagination,reqFilter,pageNo,size,function(result){
              res.send(result);
              
        })
       }
       else{
        responses = {code : "400",message : "missing parameters"};
        return   res.send(responses); 
       }
    
}

module.exports.productPaginate =  function(req,res,next){
    var responses = {};
    var reqFilter = req.body.filter;
    if(req.body.pageNo && req.body.size){
        var pageNo = parseInt(req.body.pageNo)
        var size = parseInt(req.body.size)
        if(pageNo < 0 || pageNo === 0) {
            responses = {code : "400",message : "page number greater than 0"}; 
            return res.send(responses);
        }
        commonPaginate(productPagination,reqFilter,pageNo,size,function(result){
           res.send(result);
        })
       }
       else{
        responses = {code : "400",message : "missing parameters"};
        return  res.send(responses);
       }
      
}

module.exports.bsUserPaginate =  function(req,res,next){
    var responses = {};
    var reqFilter = req.body.filter;
    if(req.body.pageNo && req.body.size){
        var pageNo = parseInt(req.body.pageNo)
        var size = parseInt(req.body.size)
        if(pageNo < 0 || pageNo === 0) {
            responses = {code : "400",message : "page number greater than 0"}; 
           return  res.send(responses);
            
        }
        commonPaginate(bsUserPagination,reqFilter,pageNo,size,function(result){
              res.send(result);
              
        })
       }
       else{
        responses = {code : "400",message : "missing parameters"};
     return   res.send(responses);
       }
      
}

var commonPaginate =  async function(modelName,reqFilter,pageNumber,pageSize,callback){
    var pager = {}
  pager.skip = pageSize * (pageNumber - 1)
  pager.limit = pageSize
   modelName.count({},function(err,countData){
      // console.log(reqFilter)
       modelName.find(reqFilter,{_id : 0, __v : 0 },pager,function(err,data) {
           var paginateCount = data.length
        if(err) {
            response = {code : "500",message : "Error fetching data"}; 
            return  callback( response);    
        } else {
            var totalPages = Math.ceil(countData / pageSize)
            if(pageNumber > totalPages ){
                response = {success : true,message : "page size exceeds",total_pages:totalPages};
            }
            else{
                response = {success : true,message : data,total_pages:totalPages,filter_count:paginateCount,total_records:countData};
            }
           
            return  callback( response);  
        }
          
    });
  })
}