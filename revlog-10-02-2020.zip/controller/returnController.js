var returns = require('../models/returnModel');
var invoice = require('../models/invoiceModel');
var returnList = require('../models/returnList');

module.exports.addInvoice = function(req,res){
   
        var invoiceObj = new invoice();
        invoiceObj.invoiceNo = req.body.invoiceNo;
        invoiceObj.date  = req.body.date;
        invoiceObj.SBU    = req.body.SBU;
        invoiceObj.customerCode = req.body.customerCode;
        invoiceObj.purchased      = req.body.purchased;
        invoiceObj.value       = req.body.value;
        invoiceObj.save(function (err) {
             if (err)
               res.json({ code : "500",
               error : "Unable to store the data"
            });
    res.json({
        success : true
            });
        });  
   
 }

 module.exports.addReturn = function(req,res){
   
    var returnObj = new returns();
    returnObj.invoiceNo = req.body.invoiceNo;
    returnObj.returnType  = req.body.returnType;
    returnObj.reasonType    = req.body.reasonType;
    returnObj.returnReason = req.body.returnReason;
    returnObj.save(function (err) {
         if (err)
           res.json({ code : "500",
           error : "Unable to store the data"
        });
res.json({
    success : true
        });
    });  

}

module.exports.getInvoice = function(req,res){
    if(!req.params.invoiceNo){
        return res.status(400).json({
            "code" : 400,
            "message": "Missing Credentials invoiceNo"
          }); 
    }
    invoice.find({invoiceNo : req.params.invoiceNo},{_id : 0, __v : 0 })
 .then((data)=>{
   res.send(data)
 })
.catch((err)=>{
    res.send(err)
});
}


module.exports.getReturnById = function(req,res){
    if(!req.params.invoiceNo){
        return res.status(400).json({
            "code" : 400,
            "message": "Missing Credentials invoiceNo"
          }); 
    }
    returns.find({invoiceNo : req.params.invoiceNo},{_id : 0, __v : 0 })
 .then((data)=>{
   res.send(data)
 })
.catch((err)=>{
    res.send(err)
});


}