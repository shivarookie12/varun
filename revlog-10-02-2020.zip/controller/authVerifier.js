const jwt = require('jsonwebtoken');
const config = require('../config/config.js');
 module.exports.authVerification=function(req,res,next){
    var token = req.get('Authorization');
    if(token){
        jwt.verify(token,config.tokenConfig.secret,function(err){
            if(err){
               return res.status(401).json({
                   "code" : 401,
                   "message": "Unauthorized"
                 }); 
            }
       next();
        })
    }
    else{
        return res.status(401).json({
            "code" : 401,
            "message": "Missing Credentials"
          }); 
    }
    
 }