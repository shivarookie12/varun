const Bcrypt = require("bcrypt");
const token = require('../token/token.js');
const uLogin = require('../models/userLoginModel');

module.exports.login = async function(req,res){
      try{
        var user = await uLogin.findOne({ email: req.body.email }).exec();
        
        var userObj = {};
        userObj.email = user.email;
        userObj.password = user.password;
        if(!user) {
            return res.status(400).send({ message: "The username does not exist" });
        }
        if(!Bcrypt.compareSync(req.body.password, user.password)) {
            return res.status(400).send({ message: "The password is invalid" });
        }
          var value = token.tokenGenerate(userObj);
          return res.status(200).json({
            "success" : true,
            "token": value
        });
      }catch(err){
        return res.status(400).send({ message: "Error occurs" });
      }
        
           
          
}

module.exports.register = function(req,res){
  var uObj = new uLogin();
  uObj.email = req.body.email;
  uObj.password  =Bcrypt.hashSync(req.body.password, 10);

  uObj.save(function (err) {
       if (err)
       return  res.json({ code : "500",
         error : err
      });
      return res.json({
     success : "true"
      });
  });  
}
module.exports.refreshToken = async function(req,res){
  var user = await uLogin.findOne({ email: req.body.email }).exec();
  if(!user) {
    return res.status(400).send({ message: "The username does not exist" });
}
        var userObj = {};
        userObj.email = user.email;
        userObj.password = user.password;  
    var value = token.refreshToken(userObj);
   return res.status(200).json({
    "success" : true,
    "refreshToken": value
    })
}