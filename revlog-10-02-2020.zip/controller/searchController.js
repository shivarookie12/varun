var customer = require('../models/customerModel.js');
module.exports.getByIdOrPhone = function(req,res){
if(!(req.body.type && req.body.value)){
    response = {code : "400",message : "missing parameter"};
    return res.send(response)
}    
getCustomerData(req.body.type,req.body.value,function(data){
    res.send(data);
})
}

getCustomerData = function(fieldName,value,callback){
    var customerQuery = customer.find();
    customerQuery.where(fieldName).equals(value).select('-_id -__v').exec(function(err,custData){
        if(err){
            response = {code : "500",message : "Error fetching data"};
            return callback(response);
        }
        response = {success : true ,customerData : custData};
        return callback(response);
    })
}

