var customer = require('../models/customerModel');
var product = require('../models/productModel');
var bsUser = require('../models/userModel.js');
module.exports.getProductCount = async function(req,res){
    var nameArr = req.body.productgroup.split(',');
    var response={};
for(var iter in nameArr){
    var result = await product.count({productgroup: nameArr[iter]}).exec();
    response[nameArr[iter]] = result ;
}
  
     return res.json({
        success : "true",
        data :response
         });
   
}  
module.exports.getCustomerCount = async function(req,res){
    var nameArr = req.body.function.split(',');
    var response={};
for(var iter in nameArr){
    var result = await customer.count({function: nameArr[iter]}).exec();
    response[nameArr[iter]] = result ;
}
  
     return res.json({
        success : "true",
        data :response
         });
   
} 
module.exports.getBusinessUserCount = async function(req,res){
    var nameArr = req.body.designation.split(',');
    var response={};
for(var iter in nameArr){
    var result = await bsUser.count({designation: nameArr[iter]}).exec();
    response[nameArr[iter]] = result ;
}
  
     return res.json({
        success : "true",
        data :response
         });
   
} 


