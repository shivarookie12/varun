const nodemailer = require('nodemailer');

const key = require('../config/revlog.json');
module.exports.sendMail = function(req,res){

var fromAddress = req.body.from;
var  toAddress = req.body.to;
var subject = req.body.subject;
var bodyText = req.body.text;
async function start() {
  const transporter = nodemailer.createTransport({
    host: 'smtp.gmail.com',
    port: 465,
    secure: true,
    auth: {
      type: 'OAuth2',
      user: fromAddress,
      serviceClient: key.client_id,
      privateKey: key.private_key,
    },
    tls: { rejectUnauthorized: false },
  });
  try {
    await transporter.verify();
    await transporter.sendMail({
      from: fromAddress,
      to: toAddress,
      subject: subject,
      text: bodyText,
    });
    return res.status(200).json({
        "success" : true
        
    });
  } catch (err) {
    return res.status(500).json({
        "error" : "error occurs in sending mail"
    })
  }
}

start();
}