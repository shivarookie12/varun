var xlsxSheet = require('xlsx');
const multer = require('multer');
var customer = require('../models/customerModel');
var product = require('../models/productModel');
var bsUser = require('../models/userModel.js');
var response = {code : 300 ,message : "file upload success "};
var errResponse  = {code : 500 ,message : "unable to store the data"};
var storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, './uploads');
  },
  filename: function (req, file, cb) {
    var datetimestamp = Date.now();
    cb(null, file.originalname);
  }
});
var upload = multer({ 
  storage: storage
}).single('file');
module.exports.uploadFile =  function(req,res){
  
 upload(req,res,function(err) {
  var fileName = req.body.fileName;
        const fileLocation = req.file.path;
  var workbook = xlsxSheet.readFile(fileLocation);
  var sheet_name_list = workbook.SheetNames;
var productData =  xlsxSheet.utils.sheet_to_json(workbook.Sheets[sheet_name_list[0]]);
var status ;

if(fileName == "product"){
 status = productRepo(productData);
 status.then(user => {

  return res.send(user);
});

}
if(fileName == "BusinessUser"){
   status = businessRepo(productData);
   status.then(user => {

    return res.send(user);
  });
  }
  if(fileName == "Customer"){
      status = customerRepo(productData);
    status.then(user => {
 
     return res.send(user);
   });
   }

    });
	
}

 productRepo = async function(productData){
   var update=0;
   var create=0;
  
  for(var dataList in productData){
    const productInfo = await product.findOne({productcode:productData[dataList].productcode}).exec();
    if(productInfo){
      const  user  =  await  product.update({productcode:productInfo.productcode}, productData[dataList],{upsert: true})
      update++;
    }
    else{
      create++;
      new product(productData[dataList])
      .save()
      .catch((err)=>{
       return errResponse;
      });
      
    }
     }
     var productRepoResponse = {created : create ,updated : update};
     return productRepoResponse;
}

businessRepo = async function(businessData){
  var update=0;
  var create=0;
 
 for(var dataList in businessData){
   const businessInfo = await bsUser.findOne({employeecode:businessData[dataList].employeecode}).exec();
   if(businessInfo){
     const  user  =  await  bsUser.update({employeecode:businessInfo.employeecode}, businessData[dataList],{upsert: true})
     update++;
   }
   else{
     create++;
     new bsUser(businessData[dataList])
     .save()
     .catch((err)=>{
      return errResponse;
     });
     
   }
    }
    var businessRepoResponse = {created : create ,updated : update};
    return businessRepoResponse;
}

customerRepo = async function(customerData){
  var update=0;
  var create=0;
 
 for(var dataList in customerData){
   const customerInfo = await customer.findOne({customercode:customerData[dataList].customercode}).exec();
   if(customerInfo){
     const  user  =  await  customer.update({customercode:customerInfo.customercode}, customerData[dataList],{upsert: true})
     update++;
   }
   else{
     create++;
     new customer(customerData[dataList])
     .save()
     .catch((err)=>{
      return errResponse;
     });
     
   }
    }
    var customerRepoResponse = {created : create ,updated : update};
    return customerRepoResponse;
}


