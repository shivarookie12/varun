var users = require('../models/userModel');
const jwt = require('jsonwebtoken');
const config = require('../config/config.js');

exports.getUser = function(req,res){
        if(!req.params.id){
            return res.status(400).json({
                "code" : 400,
                "message": "Missing Credentials id"
              }); 
        }
        users.find({userId : req.params.id},{_id : 0, __v : 0 })
     .then((data)=>{
       res.send(data)
     })
    .catch((err)=>{
        res.send(err)
    });
}
